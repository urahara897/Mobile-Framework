package apiium.mobileframework;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import io.appium.java_client.TouchAction;
import static io.appium.java_client.touch.LongPressOptions.longPressOptions;
import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;
import static java.time.Duration.ofSeconds;

import java.io.IOException;

import io.appium.java_client.touch.TapOptions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.mongodb.connection.Server;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

public class pqr extends capabilities {
	

		
		AndroidDriver<AndroidElement> driver ;
		@BeforeTest
		public void BT() throws IOException, InterruptedException {
		
			
			
		}
		
		@Test(enabled = false)
		public void testcase() throws InterruptedException {
			//positive testing
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.id("com.androidsample.generalstore:id/spinnerCountry")).click();
		driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"India\"))").click();
		driver.findElement(By.id("com.androidsample.generalstore:id/nameField")).sendKeys("Rudro");
		//driver.findElement(By.xpath("//*[@text='Female']")).click();
		driver.findElement(By.id("com.androidsample.generalstore:id/btnLetsShop")).click();
		driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Converse All Star\"))");		
}
		
		@Test(enabled = false)
		public void testcase1() {
			//negative testing
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			//driver.findElement(By.id("com.androidsample.generalstore:id/spinnerCountry")).click();
			//driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"India\"))").click();
			//driver.findElement(By.id("com.androidsample.generalstore:id/nameField")).sendKeys("Rudro");
			driver.findElement(By.id("com.androidsample.generalstore:id/btnLetsShop")).click();
			String error= driver.findElement(By.xpath("//android.widget.Toast[1]")).getAttribute("name");
			System.out.println(error);
			//driver.findElement(By.xpath("//*[@text='Female']")).click();
			
			//driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Converse All Star\"))");
			
		}
		
		@Test(enabled = false)
		public void testcase3() {
			
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			//driver.findElement(By.id("com.androidsample.generalstore:id/spinnerCountry")).click();
			//driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"India\"))").click();
			driver.findElement(By.id("com.androidsample.generalstore:id/nameField")).sendKeys("Rudro");
			//driver.findElement(By.xpath("//*[@text='Female']")).click();
			driver.findElement(By.id("com.androidsample.generalstore:id/btnLetsShop")).click();
			//driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Converse All Star\"))");		
			//driver.findElements(By.xpath("//*[@text='ADD TO CART']")).get(0).click();
			//driver.findElements(By.xpath("//*[@text='ADD TO CART']")).get(0).click();
			//to find how many products are there
			//to scroll to an element to make the element in the instance of 0(first product)
			//scroll based on product list identified by someone
			//driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().resourceId(\"com.androidsample.generalstore:id/rvProductList\")).scrollIntoView(textMatches(\"Jordan 6 Rings\").instance(0))");
			//driver.findElementsByAndroidUIAutomator("new UiScrollable(new UiSelector().resourceId(\"com.androidsample.generalstore:id/productName\")).scrollIntoView(new UiSelector().text(\"Converse All Star\"))");
			driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().resourceId(\"com.androidsample.generalstore:id/rvProductList\")).scrollIntoView(new UiSelector().textMatches(\"Jordan 6 Rings\"))");
			//what if i want to click on the specific element add to cart jordon 6 rings
			//driver.findElementsByAndroidUIAutomator("new UiScrollable(new UiSelector().resourceId(\"com.androidsample.generalstore:id/productName\")).scrollIntoView(new UiSelector().text(\"Jordan 6 Rings\"))");
			int count = driver.findElements(By.id("com.androidsample.generalstore:id/productName")).size();
			for(int i=0;i<count;i++)
			{
				String productName = driver.findElements(By.id("com.androidsample.generalstore:id/productName")).get(i).getText();
				if(productName.equalsIgnoreCase("Jordan 6 Rings"))
				{
					System.out.println(productName);
					driver.findElements(By.id("com.androidsample.generalstore:id/productAddCart")).get(i).click();
					break;
				}
			}
			System.out.println("clicked on jordan 6 rings");
			
		}
				
		@Test
		public void testcase4() throws InterruptedException, IOException {
			driver = capability();
			service = startServer();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			//driver.findElement(By.id("com.androidsample.generalstore:id/spinnerCountry")).click();
			//driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"India\"))").click();
			driver.findElement(By.id("com.androidsample.generalstore:id/nameField")).sendKeys("Rudro");
			//driver.findElement(By.xpath("//*[@text='Female']")).click();
			driver.findElement(By.id("com.androidsample.generalstore:id/btnLetsShop")).click();
			//driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Converse All Star\"))");	
			Thread.sleep(3000);
			driver.findElements(By.xpath("//*[@text='ADD TO CART']")).get(0).click();
			driver.findElements(By.xpath("//*[@text='ADD TO CART']")).get(0).click();
			driver.findElement(By.id("com.androidsample.generalstore:id/appbar_btn_cart")).click();
			Thread.sleep(3000);
			String amount1 = driver.findElements(By.id("com.androidsample.generalstore:id/productPrice")).get(0).getText();
			//to remove dollar
			amount1=amount1.substring(1);
			String amount2 = driver.findElements(By.id("com.androidsample.generalstore:id/productPrice")).get(1).getText();
			amount2 =amount2.substring(1);
			Double amt1=Double.parseDouble(amount1);
			Double amt2 = Double.parseDouble(amount2);
			String total = driver.findElement(By.id("com.androidsample.generalstore:id/totalAmountLbl")).getText();
			total = total.substring(1);
			Double TotalValue = Double.parseDouble(total);
			Double totalcart = amt1 + amt2;
			AssertJUnit.assertEquals(TotalValue, totalcart);
			System.out.println("pass");
			WebElement xyz = driver.findElement(By.id("com.androidsample.generalstore:id/bottomBar"));
			WebElement abc = driver.findElement(By.id("com.androidsample.generalstore:id/termsButton"));
			TouchAction t = new TouchAction(driver);
			t.tap(tapOptions().withElement(element(xyz))).perform();
			t.longPress(longPressOptions().withElement(element(abc)).withDuration(ofSeconds(2))).release().perform();
			driver.findElement(By.id("android:id/button1")).click();
			driver.findElement(By.xpath("//*[@text='Visit to the website to complete purchase']")).click();
			Thread.sleep(9000);
			Set<String> contextNames = driver.getContextHandles();
			for (String contextName : contextNames) {
			System.out.println(contextName);
			
			
			}
			
			
			driver.context("WEBVIEW_com.androidsample.generalstore");
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@name='q']")).sendKeys("moolya");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//*[@name='q']")).sendKeys(Keys.ENTER);
			Thread.sleep(5000);
			driver.pressKey(new KeyEvent(AndroidKey.BACK));
			driver.context("NATIVE_APP");
			service.stop();
		}
		
		
		}
